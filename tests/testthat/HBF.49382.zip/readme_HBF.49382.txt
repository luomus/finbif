Tämän latauksen tietosivu ja viittausohjeet: http://tun.fi/HBF.49381

Lataus on tehty 15.2.2021 seuraavilla rajauksilla:
Aika: 2020-01-01/
Lataus tietovarastoon, päivänä tai ennen: 2021-02-15
Virheelliset tietueet mukana: Vain virheelliset
Linkki hakuun: 
https://laji.fi/fi/observation/list?time=2020-01-01%2F&loadedSameOrBefore=2021-02-15&qualityIssues=ONLY_ISSUES 

Lataus koostuu seuraavista aineistoista joille on määritelty 
käyttöoikeuslisenssi: 

Aphyllophorales Fennoscandiae orientalis - http://tun.fi/HR.139
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa soili.stenroos@helsinki.fi

LajiGIS: Lajistokartoitus vesistössä - http://tun.fi/HR.3491
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa essi.keskinen@metsa.fi; 
ari.laine@metsa.fi 

Lajitietokeskus - Mikä laji? -havainnot - http://tun.fi/HR.2832
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Lajitietokeskus - Vihkon yleiset havainnot - http://tun.fi/HR.1747
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Lajitietokeskus - iNaturalist Suomi Finland - http://tun.fi/HR.3211
Kaikki oikeudet pidätetään
Lisätietoja tämän aineiston käytöstä antaa mikko.heikkinen@helsinki.fi

Luonto-Liiton kevätseuranta - http://tun.fi/HR.206
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa kevatseuranta@luontoliitto.fi

Löydöksen vieraslajihavainnot - http://tun.fi/HR.435
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Löydös havaintopalvelu - http://tun.fi/HR.203
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa info@laji.fi

Oulun yliopiston (OULU) putkilokasvikokoelmat - http://tun.fi/HR.427
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa jouni.aspi@oulu.fi

Oulun yliopiston kasvimuseon sammalkokoelma (HERBARIUM UNIVERSITATIS OULUENSIS) 
- http://tun.fi/HR.1267 
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa annu.ruotsalainen@oulu.fi

Oulun yliopiston kasvimuseon sienikokoelma (HERBARIUM UNIVERSITATIS OULUENSIS) 
- http://tun.fi/HR.1367 
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa annu.ruotsalainen@oulu.fi

Pienet hyönteislahkot (Luomus) - http://tun.fi/HR.165
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa heidi.viljanen@helsinki.fi

Sammakkoeläinten ja matelijoiden levinneisyyskartoitus - http://tun.fi/HR.847
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa markus.piha@helsinki.fi

Sieniatlas - http://tun.fi/HR.2129
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa tea.vonbonsdorff@helsinki.fi

TUR Turun kasvimuseon sienikokoelmat - http://tun.fi/HR.1407
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa seppo.huhtinen@utu.fi

Turun yliopiston kasvimuseon sammalhavainnot - http://tun.fi/HR.2733
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa tarja.marsh@utu.fi

Valtakunnallinen päiväperhosseuranta (NAFI) - http://tun.fi/HR.175
Creative Commons Nimeä
Lisätietoja tämän aineiston käytöstä antaa kimmo.saarinen@allergia.fi


---

Information about this download and citation instructions: 
http://tun.fi/HBF.49381 

This download is made on 2021-02-15 using the following filters:
Time: 2020-01-01/
Loaded to data warehouse, on or before: 2021-02-15
Records with quality issues included: Only issues
Link to search: 
https://laji.fi/en/observation/list?time=2020-01-01%2F&loadedSameOrBefore=2021-02-15&qualityIssues=ONLY_ISSUES 

This download consists of data from the following information sources and they 
each have their own copyright-license: 

Aphyllophorales Fennoscandiae orientalis - http://tun.fi/HR.139
Creative Commons Attribution
More information about using this information source can be requested from 
soili.stenroos@helsinki.fi 

Atlas of amphibians and reptiles in Finland - http://tun.fi/HR.847
Creative Commons Attribution
More information about using this information source can be requested from 
markus.piha@helsinki.fi 

Bryophyte collection of the Botanical Museum, University of Oulu (OULU) 
(HERBARIUM UNIVERSITATIS OULUENSIS) - http://tun.fi/HR.1267 
Creative Commons Attribution
More information about using this information source can be requested from 
annu.ruotsalainen@oulu.fi 

Bryophyte observations of Turku university Herbarium - http://tun.fi/HR.2733
Creative Commons Attribution
More information about using this information source can be requested from 
tarja.marsh@utu.fi 

Fungal atlas - http://tun.fi/HR.2129
Creative Commons Attribution
More information about using this information source can be requested from 
tea.vonbonsdorff@helsinki.fi 

Fungal collection of the Botanical Museum, University of Oulu (OULU) (HERBARIUM 
UNIVERSITATIS OULUENSIS) - http://tun.fi/HR.1367 
Creative Commons Attribution
More information about using this information source can be requested from 
annu.ruotsalainen@oulu.fi 

LajiGIS: Aquatic species survey - http://tun.fi/HR.3491
Creative Commons Attribution
More information about using this information source can be requested from 
essi.keskinen@metsa.fi; ari.laine@metsa.fi 

Lajitietokeskus - Notebook, general observations - http://tun.fi/HR.1747
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Lajitietokeskus - Which species? observation - http://tun.fi/HR.2832
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Lajitietokeskus - iNaturalist Suomi Finland - http://tun.fi/HR.3211
All rights reserved
More information about using this information source can be requested from 
mikko.heikkinen@helsinki.fi 

Löydös Open Finnish Observation Database - http://tun.fi/HR.203
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Löydös Open Invasive Species Observations - http://tun.fi/HR.435
Creative Commons Attribution
More information about using this information source can be requested from 
info@laji.fi 

Minor insect orders (Luomus) - http://tun.fi/HR.165
Creative Commons Attribution
More information about using this information source can be requested from 
heidi.viljanen@helsinki.fi 

National Finnish butterfly monitoring scheme (NAFI) - http://tun.fi/HR.175
Creative Commons Attribution
More information about using this information source can be requested from 
kimmo.saarinen@allergia.fi 

TUR Fungus collections of the Turku University - http://tun.fi/HR.1407
Creative Commons Attribution
More information about using this information source can be requested from 
seppo.huhtinen@utu.fi 

The Finnish Nature League's Spring monitoring - http://tun.fi/HR.206
Creative Commons Attribution
More information about using this information source can be requested from 
kevatseuranta@luontoliitto.fi 

Vascular plant collections of the Botanical Museum, University of Oulu (OULU) - 
http://tun.fi/HR.427 
Creative Commons Attribution
More information about using this information source can be requested from 
jouni.aspi@oulu.fi 


---

Information om den här nedladdningen och citat instruktioner: 
http://tun.fi/HBF.49381 

Den här nedladdningen är gjord 15.2.2021 med följande filter:
Tid: 2020-01-01/
Laddning till datalager, på eller före: 2021-02-15
Rekord med kvalitetsproblem ingår: Endast med problem
Länk till sökning: 
https://laji.fi/sv/observation/list?time=2020-01-01%2F&loadedSameOrBefore=2021-02-15&qualityIssues=ONLY_ISSUES 

Den här nedladdningen består av data från följande informationskällor och de 
har var sin egen upphovsrättslicens: 

Aphyllophorales Fennoscandiae orientalis - http://tun.fi/HR.139
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
soili.stenroos@helsinki.fi 

Grod- och kräldjurens utbredningskartering - http://tun.fi/HR.847
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
markus.piha@helsinki.fi 

LajiGIS: Lajistokartoitus vesistössä - http://tun.fi/HR.3491
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
essi.keskinen@metsa.fi; ari.laine@metsa.fi 

Lajitietokeskus - Mikä laji? -havainnot - http://tun.fi/HR.2832
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Lajitietokeskus - Skrivbok - http://tun.fi/HR.1747
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Lajitietokeskus - iNaturalist Suomi Finland - http://tun.fi/HR.3211
Alla rättigheter förbehålls
Mer information om den här informationskälla kan beställas från 
mikko.heikkinen@helsinki.fi 

Luonto-Liittos och Natur och Miljös Följ med våren - http://tun.fi/HR.206
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
kevatseuranta@luontoliitto.fi 

Löydös Open Observation Database - http://tun.fi/HR.203
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Löydös invasiva arter observationer - http://tun.fi/HR.435
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från info@laji.fi

Ordines minores (Luomus) - http://tun.fi/HR.165
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
heidi.viljanen@helsinki.fi 

Oulun yliopiston (OULU) putkilokasvikokoelmat - http://tun.fi/HR.427
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
jouni.aspi@oulu.fi 

Oulun yliopiston kasvimuseon sammalkokoelma (HERBARIUM UNIVERSITATIS OULUENSIS) 
- http://tun.fi/HR.1267 
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
annu.ruotsalainen@oulu.fi 

Oulun yliopiston kasvimuseon sienikokoelma (HERBARIUM UNIVERSITATIS OULUENSIS) 
- http://tun.fi/HR.1367 
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
annu.ruotsalainen@oulu.fi 

Sieniatlas - http://tun.fi/HR.2129
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
tea.vonbonsdorff@helsinki.fi 

TUR Turun kasvimuseon sienikokoelmat - http://tun.fi/HR.1407
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
seppo.huhtinen@utu.fi 

Turun yliopiston kasvimuseon sammalhavainnot - http://tun.fi/HR.2733
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
tarja.marsh@utu.fi 

Valtakunnallinen päiväperhosseuranta (NAFI) - http://tun.fi/HR.175
Creative Commons Erkännande
Mer information om den här informationskälla kan beställas från 
kimmo.saarinen@allergia.fi 

